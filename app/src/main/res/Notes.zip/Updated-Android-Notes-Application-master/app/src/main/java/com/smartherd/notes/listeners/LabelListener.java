package com.smartherd.notes.listeners;

import com.smartherd.notes.Entitites.Label;

public interface LabelListener {
    void onLabelClicked(int position);
}
